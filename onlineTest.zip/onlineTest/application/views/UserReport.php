      <?php include'header.php'?>
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><a href="javascript:void(0)">View Report</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">All Report</a></li>
					</ol>
                </div>
				
                <div class="row">
					<div class="col-lg-12">
						<div class="card">
							<div class="card-header">
								  <h4></h4>
<?php
if($user_data['u_status']==1){ ?>
								  <a href="<?php echo base_url('addReport'); ?>" class="btn btn-primary">Add Report</a>
								<?php } ?>
							 </div>
							 <div class="card-body">
								 <div class="table-responsive ticket-table">
									<table id="example" class="display  table table-bordered  table-responsive-xl" style="min-width: 845px">
										<thead>
											<tr>
											  
												
												<th>Sl.No</th>
												<?php
if($user_data['u_status']==2){ ?>
<th>User Name</th>
	<?php

} ?>
												<th>Weak Date Range</th>
												<th>Description</th>
												<th>File</th>
												<th>Actions</th>
												
											</tr>
										</thead>
										<tbody>
											<?php if(!empty($report)){
												$i=1;
												foreach($report as $res){
													
												?>

											<tr>
												   
												
												<td><?php  echo $i; ?></td>

<?php
if($user_data['u_status']==2){ ?>
<th><?php echo $res->u_name; ?></th>
	<?php

} ?>



												<td><?php echo $res->fromdate."--".$res->todate; ?></td>
												<td class="table-para"><div><?php echo $res->desc; ?>
												</div> </td>
												<td><a href="<?php echo base_url()."public/uploads/".$res->filesata;  ?>" >View</a></td>
												<td>
													<div class="d-flex">
														<a href="<?php echo base_url('editReport/'); ?><?php echo $res->id; ?>" class="btn btn-primary shadow btn-xs sharp me-1"><i class="fas fa-pencil-alt"></i></a>
														<a  onclick="deletedata(<?php echo $res->id; ?>)" class="btn btn-danger shadow btn-xs sharp"><i class="fa fa-trash"></i></a>
													</div>
												</td>
											</tr>
											
												<?php

											$i++; }  }else{
												?>
												<tr><td colspan="4">No Data</td></tr>
												<?php
											} ?>
										  
										</tbody>
									   
									</table>
								</div>
							</div>
						</div>
                    </div>
				</div>
            </div>
        </div>
        <script type="text/javascript">
        	function deletedata(id){
        		if (confirm("Are you sure?")) {
        			  var formData = {'id':id}
$.ajax({
        type: 'POST',
        url: '<?php echo base_url('deletReport'); ?>',
        data: formData,
        success: function(response) {
          // Handle the response from the server
          location.reload();
        }
      });

      
    }
    return false;
  
        	}
        </script>
        <!--**********************************
            Content body end
        ***********************************-->
		<?php include'footer.php'?>