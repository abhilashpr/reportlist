      <?php include'header.php'?>
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><a href="javascript:void(0)">View Report  By User</a></li>
						<li class="breadcrumb-item"><a href="javascript:void(0)">All Report By User</a></li>
					</ol>
                </div>
				
                <div class="row">
                	<form method="GET">
                	<div class="col-lg-4">
								<select class="form-control" name="userid">
								<option value="0">Select User</option>
								<?php 
if(!empty($userlist)){
	foreach($userlist as $u){
		?>
		<option <?php if(isset($_GET['userid'])){ if($_GET['userid']==$u->u_id){ echo "selected";  } } ?> value="<?php echo $u->u_id; ?>"><?php echo $u->u_name; ?></option>
		<?php

	}

}
								?>
							</select>
							</div>
							<div class="col-lg-4">
								<button type="submit" class="btn btn-success" >Filter</button>
							</div>
						</form>
					<div class="col-lg-12">
						<div class="card">
							

							
							 <div class="card-body">
								 <div class="table-responsive ticket-table">
									<table id="example" class="display  table table-bordered  table-responsive-xl" style="min-width: 845px">
										<thead>
											<tr>
											  
												<th>Sl.No</th>
												
												<th>User Name</th>
												<th>Total Reports</th>
	
												
												
											</tr>
										</thead>
										<tbody>
											<?php if(!empty($report)){
												$i=1;
												foreach($report as $res){
													
												?>

											<tr>
												   
												
												<td><?php  echo $i; ?></td>
												<th><a href="<?php echo base_url('UserReport/').$res->user_id; ?>"><?php echo $res->u_name; ?></a></th>
												<th><?php echo $res->cnts; ?></th>

												
												
											</tr>
											
												<?php

											$i++; }  }else{
												?>
												<tr><td colspan="4">No Data</td></tr>
												<?php
											} ?>
										  
										</tbody>
									   
									</table>
								</div>
							</div>
						</div>
                    </div>
				</div>
            </div>
        </div>
        <script type="text/javascript">
        	function deletedata(id){
        		if (confirm("Are you sure?")) {
        			  var formData = {'id':id}
$.ajax({
        type: 'POST',
        url: '<?php echo base_url('deletReport'); ?>',
        data: formData,
        success: function(response) {
          // Handle the response from the server
          location.reload();
        }
      });

      
    }
    return false;
  
        	}
        </script>
        <!--**********************************
            Content body end
        ***********************************-->
		<?php include'footer.php'?>