<?php include'header.php'?>

<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)"><?php  echo !empty($reportdata)?"Update Report":"Add Report"; ?></a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)"><?php  echo !empty($reportdata)?"Update Report":"Add Report"; ?></a></li>

            </ol>
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <!-- -------form-validation----- -->
                        <div class="form-validation">
	<p style="color:red"> <?php  echo $this->session->flashdata('msg'); ?></p>

                            <div class="needs-validation" novalidate="">
                            	 <?php if(!empty($reportdata)){ 
$url='updatereport_fn';
                            	 }else{
                            	 	$url='addreport_fn';
                            	 } ?>

<form action="<?php echo base_url($url); ?>" method="POST"   enctype="multipart/form-data" autocomplete="off" >
                                <div class="row">
                                   
                                    <div class="mb-3 row">
                                            <label class="col-lg-3 col-form-label" for="validationCustom03">
                                               From Date
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-9">
                                            <input name="fromdate" value="<?php if(!empty($reportdata)){ echo date("d M, Y",strtotime($reportdata[0]->fromdate)); } ?>" required class="datepicker-default form-control" id="datepicker">
                                                
                                            </div>
                                        </div>
 										<div class="mb-3 row">
                                            <label class="col-lg-3 col-form-label" for="validationCustom03">
                                               To Date
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-lg-9">
                                            <input name="todate" value="<?php if(!empty($reportdata)){ echo date("d M, Y",strtotime($reportdata[0]->todate)); } ?>" required class="datepicker-default form-control" id="datepicker">
                                                
                                            </div>
                                        </div>


                                    <div class="row mb-3">
                                        <div class="col-xl-3">
                                            <label class="col-lg-10 col-form-label" for="validationCustom06">
                                                Description <span class="text-danger">*</span>
                                            </label>
                                        </div>
                                        <div class="col-xl-9">
                                            <div class="custom-ekeditor ct-ticket">
                                             <textarea class="form-control"   name="desc" placeholder="Description" ><?php if(!empty($reportdata)){ echo $reportdata[0]->desc; } ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label class="col-lg-3 col-form-label" for="validationCustom07">
                                             File <span class="text-danger">*</span>
                                        </label>
                                        <div class="col-xl-9">
                                            <div class="ticket-file">

                                                
                                                    <div class="fallback">
                                                    	<input type="hidden" name="wkid" value="<?php if(!empty($reportdata)){ echo $reportdata[0]->id; } ?>">

                                                    	<input type="hidden" name="oldfile" value="<?php if(!empty($reportdata)){ echo $reportdata[0]->filesata; } ?>">
                                                        <input name="file" type="file" multiple="">
                                                    </div>
                                                    <?php if(!empty($reportdata)){  ?>
                                                    <a target="_blank" href="<?php echo base_url()."public/uploads/".$reportdata[0]->filesata ?>" >View File<a>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3 row">
                                        <div class="col-lg-9 ms-auto">
                                            <button type="submit" name="savebtn" class="btn btn-primary"><?php  echo !empty($reportdata)?"Update Report":"Add Report"; ?></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                    <!-- -------form-validation----- -->


                </div>
            </div>
        </div>
    </div>

</div>
</div>
<!--**********************************
            Content body end
        ***********************************-->
<?php include'footer.php'?>