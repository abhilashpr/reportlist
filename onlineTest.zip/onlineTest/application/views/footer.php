<!--**********************************
    Footer start
***********************************-->
<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="" target="_blank">Demo</a> 2023</p>
    </div>
</div>
<!--**********************************
    Footer end
***********************************-->

<!--**********************************
   Support ticket button start
***********************************-->

<!--**********************************
   Support ticket button end
***********************************-->


</div>
<!--**********************************
Main wrapper end
***********************************-->

<!--**********************************
Scripts
***********************************-->
<!-- Required vendors -->
<script src="<?php echo base_url('public/assets/') ; ?>vendor/global/global.min.js"></script>
<script src="<?php echo base_url('public/assets/') ; ?>vendor/dropzone/dist/dropzone.js"></script>
	<script src="<?php echo base_url('public/assets/') ; ?>vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="<?php echo base_url('public/assets/') ; ?>vendor/bootstrap-datetimepicker/js/moment.js"></script>
	<script src="<?php echo base_url('public/assets/') ; ?>vendor/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
	<script src="<?php echo base_url('public/assets/') ; ?>vendor/select2/js/select2.full.min.js"></script>
	<script src="<?php echo base_url('public/assets/') ; ?>vendor/ckeditor/ckeditor.js"></script>
    <!-- Daterangepicker -->
    
     <!-- pickdate -->
    <script src="<?php echo base_url('public/assets/') ; ?>vendor/pickadate/picker.js"></script>
    <script src="<?php echo base_url('public/assets/') ; ?>vendor/pickadate/picker.time.js"></script>
    <script src="<?php echo base_url('public/assets/') ; ?>vendor/pickadate/picker.date.js"></script>

    <!-- Pickdate -->
    <script src="<?php echo base_url('public/assets/') ; ?>js/plugins-init/pickadate-init.js"></script>

	<!-- Datatable -->
    <script src="<?php echo base_url('public/assets/') ; ?>vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url('public/assets/') ; ?>js/plugins-init/datatables.init.js"></script>

	<!-- Form validate init -->
	 <script src="<?php echo base_url('public/assets/') ; ?>js/plugins-init/select2-init.js"></script>
    <script src="<?php echo base_url('public/assets/') ; ?>js/custom.min.js"></script>
	<script src="<?php echo base_url('public/assets/') ; ?>js/deznav-init.js"></script>
	<script src="<?php echo base_url('public/assets/') ; ?>js/demo.js"></script>
    <!-- <script src="js/styleSwitcher.js"></script> -->
</body>
</html>