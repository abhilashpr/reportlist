       <?php include'header.php'?>
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body rightside-event">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
					
						<div class="col-xl-4 col-xxxl-12 col-lg-4">
						<div class="card">
							<div class="card-body">
								<div class="d-flex">
									<span  class="box-icon"><i class="fa fa-archive" aria-hidden="true"></i></span>
									<div class="content-box">
										<h4><?php echo $u_status==1?"Your ":"" ?>Total Reports</h4>
										<h6><?php echo $total_order." reports"; ?></h6>
									</div>
								</div>
							</div>
				       </div>
					</div>

					
					
						
				<div class="row">
					<div class="col-xl-12">
						<div id="user-activity" class="card">
							<div class="card-header border-0 pb-0 d-sm-flex d-block">
								<div>
									<h4 class="card-title mb-1"><?php echo $u_status==1?"Your ":"" ?> Recent Orders</h4>
									
								</div> 
								<a  class="btn btn-success" href="<?php echo base_url('ViewReport'); ?>" >View All</a>
								
							</div>
							<div class="card-body">
							<div class="table-responsive ticket-table">
							<table id="example" class="display  table table-bordered  table-responsive-xl" style="min-width: 845px">
                                <thead>
                                    <tr>
                                      	
                                        
                                       <th>Sl.No</th>
												<?php if($u_status==2){?> <th>User</th> <?php  } ?>

												<th>Weak Date Range</th>
												<th>Description</th>
												<th>File</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
											<?php if(!empty($recent_orders)){
												$i=1;
												foreach($recent_orders as $res){
													
												?>

											<tr>
												   
												
												<td><?php  echo $i; ?></td>
												<?php if($u_status==2){?> <td><?php  echo $res->u_name; ?></td> <?php  } ?>

												<td><?php echo $res->fromdate."--".$res->todate; ?></td>
												<td class="table-para"><div><?php echo $res->desc; ?>
												</div> </td>
												<td><a href="<?php echo base_url()."public/uploads/".$res->filesata;  ?>" >View</a></td>
												
											</tr>
											
												<?php

											$i++; }  }else{
												?>
												<tr><td colspan="4">No Data</td></tr>
												<?php
											} ?>
										  
										</tbody>
                               
                            </table>
								</div>
							</div>
						</div>
					</div>
					
					
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->




        
		<?php include'footer.php'?>
