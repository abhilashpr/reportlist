<?php
class Loginmodel extends CI_Model {
    public function insert_user($data) {
        $this->db->insert('users', $data);
        return $this->db->insert_id();
    }


public function logindata($username,$password){
	$this->db->select('*');
$this->db->from('users');
$this->db->where('username', $username);
$this->db->where('password', $password);
$query = $this->db->get();
if ( $query->num_rows() > 0 )
    {
        $row = $query->row_array();
        return $row;
    }

}



 public function deptmnt(){
    $this->db->select('*');
$this->db->from('departments');


$query = $this->db->get();
if ( $query->num_rows() > 0 )
    {
        $row = $query->result();  
        return $row;
    }

}


}
