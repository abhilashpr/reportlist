<?php
class Dashboardmodal extends CI_Model {
    public function insert_data($data) {
        $this->db->insert('wk_report', $data);
        return $this->db->insert_id();
    }

public function update_data($data,$id){
	$this->db->where('id', $id);
	$this->db->update('wk_report',$data);
return 1;
}


 public function total_orders($user_data){
	$this->db->select('count(id) as tot');
$this->db->from('wk_report');
if($user_data['u_status']==1){
$this->db->where('user_id', $user_data['user_id']);

}
$this->db->join("users","users.u_id=wk_report.user_id","left");

$this->db->where('users.u_dpmt', $user_data['u_dpmt']);

$query = $this->db->get();
$row = $query->result();  
        return $row[0];

}

 public function recent_orders($user_data){
	$this->db->select('wk_report.*,users.u_name');
$this->db->from('wk_report');

if($user_data['u_status']==1){
$this->db->where('user_id', $user_data['user_id']);

}

$this->db->join("users","users.u_id=wk_report.user_id","left");
$this->db->where('users.u_dpmt', $user_data['u_dpmt']);

$this->db->order_by("id","DESC");
$this->db->limit(10);
$query = $this->db->get();
if ( $query->num_rows() > 0 )
    {
        $row = $query->result();  
        return $row;
    }

}


 public function reportByUser($userid,$user_data){
	$this->db->select('wk_report.*,users.u_name,COUNT(users.u_name) as cnts ');
$this->db->from('wk_report');


$this->db->join("users","users.u_id=wk_report.user_id","left");
if(!empty($userid)){
$this->db->where('wk_report.user_id', $userid);

}
$this->db->where('users.u_dpmt', $user_data['u_dpmt']);
$this->db->group_by("user_id");
$query = $this->db->get();
if ( $query->num_rows() > 0 )
    {
        $row = $query->result();  
        return $row;
    }

}

 public function UserReport($userid){
	$this->db->select('wk_report.*,users.u_name');
$this->db->from('wk_report');

$this->db->where('user_id', $userid);

$this->db->join("users","users.u_id=wk_report.user_id","left");


$this->db->order_by("id","DESC");
$query = $this->db->get();
if ( $query->num_rows() > 0 )
    {
        $row = $query->result();  
        return $row;
    }

}


 public function userlist($user_data){
	$this->db->select('*');
$this->db->from('users');

$this->db->where('u_status!=',2);
$this->db->where('users.u_dpmt', $user_data['u_dpmt']);

$this->db->order_by("u_id","DESC");
$query = $this->db->get();
if ( $query->num_rows() > 0 )
    {
        $row = $query->result();  
        return $row;
    }

}





    public function viewreport($user_data){
	$this->db->select('wk_report.*,users.u_name');
$this->db->from('wk_report');

if($user_data['u_status']==1){
$this->db->where('user_id', $user_data['user_id']);

}
$this->db->join("users","users.u_id=wk_report.user_id","left");

$this->db->where('users.u_dpmt', $user_data['u_dpmt']);

$this->db->order_by("id","DESC");
$query = $this->db->get();
if ( $query->num_rows() > 0 )
    {
        $row = $query->result();  
        return $row;
    }

}

 public function viewreportByid($id){
	$this->db->select('*');
$this->db->from('wk_report');
$this->db->where('id', $id);

$query = $this->db->get();
if ( $query->num_rows() > 0 )
    {
        $row = $query->result();  
        return $row;
    }

}

 public function deletereport($id){
	$this->db->where('id', $id);
	$this->db->delete('wk_report');
return 1;

}


}
