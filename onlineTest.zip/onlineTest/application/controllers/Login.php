<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	 public function __construct() {
            parent::__construct();
            $this->load->helper('url_helper');
            $this->load->model('Loginmodel');
            $this->load->model('Dashboardmodal');
            $this->load->library('session');

          
        }

	public function index()
	{
		$user_data = $this->session->userdata('user_data');
if(!empty($user_data)){
	redirect("Dashboard");

}else{
		$this->load->view('login');

}
	}



public function login_fn(){
	if(isset($_POST['logbtn'])){

$username=$this->input->post('username');
$password=$this->input->post('password');

		 $res=$this->Loginmodel->logindata($username,$password);

		$data = array(
    'user_id' => $res['u_id'],
    'username' => $res['username'],
    'u_dpmt' => $res['u_dpmt'],
    'u_status'=>$res['u_status'],
);

$this->session->set_userdata('user_data',$data);

redirect('dashboard');

	}
}



}
