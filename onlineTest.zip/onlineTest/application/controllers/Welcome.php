<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	 public function __construct() {
            parent::__construct();
            $this->load->helper('url_helper');
            $this->load->model('Loginmodel');
            $this->load->library('session');
          
        }



	public function index()
	{
		$this->load->view('login');
	}
	public function Register()
	{
 $res['department']=$this->Loginmodel->deptmnt();


		$this->load->view('register',$res);
	}


public function register_fn(){

	if(isset($_POST['savebtn'])){

		$data=array(
"u_name"=>$this->input->post('name'),
"u_dpmt"=>$this->input->post('dptmnt'),
"u_status"=>1,
"username"=>$this->input->post('username'),
"password"=>$this->input->post('password'),
		);


 $res=$this->Loginmodel->insert_user($data);


$data = array(
    'user_id' => $res,
    'username' => $this->input->post('username'),
    'u_dpmt' => $this->input->post('dptmnt'),
    'u_status' => 1
);

$this->session->set_userdata('user_data',$data);

redirect('dashboard');



	}else{
		
		redirect("login");
	}
}

public function logout(){
	$this->session->unset_userdata('user_data');
	redirect("login");
}


}
