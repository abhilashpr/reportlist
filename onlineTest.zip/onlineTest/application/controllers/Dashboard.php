<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	 public function __construct() {
            parent::__construct();
            $this->load->helper('url_helper');
            $this->load->model('Loginmodel');
            $this->load->model('Dashboardmodal');
            $this->load->library('session');

          
        }

public function index()
	{

$user_data = $this->session->userdata('user_data');
if(!empty($user_data)){


$total_order=$this->Dashboardmodal->total_orders($user_data);
$recent_orders=$this->Dashboardmodal->recent_orders($user_data);

$data=array(
"user_id"=>$user_data['user_id'],
"username"=>$user_data['username'],
"u_dpmt"=>$user_data['u_dpmt'],
"u_status"=>$user_data['u_status'],
"total_order"=>$total_order->tot,
"recent_orders"=>$recent_orders,
);
	$this->load->view('dashboard',$data);


}else{
	redirect('Login');
}

	}

	public function addReport(){
		$user_data = $this->session->userdata('user_data');
if(!empty($user_data)){
			$this->load->view('addreport');
	}
}

	public function updatereport_fn(){
			$user_data = $this->session->userdata('user_data');
if(!empty($user_data)){

if(isset($_POST['savebtn'])){


 if(!empty($_FILES['file']['tmp_name'])){
 $file_tmp =$_FILES['file']['tmp_name']; 

 $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));

$filename=date("Ymdhsi").$user_data['user_id'].".".$file_ext;
move_uploaded_file($file_tmp,"public/uploads/".$filename);

}else{
	$filename=$this->input->post('oldfile');
}


$id=$this->input->post('wkid');

		$data=array(
"fromdate"=>date("Y-m-d",strtotime($this->input->post('fromdate'))),
"todate"=>date("Y-m-d",strtotime($this->input->post('todate'))),
"desc"=>$this->input->post('desc'),
"filesata"=>$filename,
"created_at"=>date("Y-m-d"),

"updated_by"=>$user_data['user_id'],


		);

 $res=$this->Dashboardmodal->update_data($data,$id);


$this->session->set_flashdata('msg','Successfully Updated');
redirect('editReport/'.$id);

	}else{
		
		redirect("login");
	}




}
}


public function deletReport(){
	$user_data = $this->session->userdata('user_data');
if(!empty($user_data)){

$id=$_POST['id'];
$res=$this->Dashboardmodal->viewreportByid($id);

if(!empty($res)){
	if(!empty($res[0]->filesata)){
	
	unlink('public/uploads/'.$res[0]->filesata);

	}

 $ress=$this->Dashboardmodal->deletereport($id);
	return 1;

}else{
	return 0;
}


}else{
	return 0;
}
}




	public function addreport_fn(){
			$user_data = $this->session->userdata('user_data');
if(!empty($user_data)){

			if(isset($_POST['savebtn'])){

$filename='';
if(!empty($_FILES['file']['tmp_name'])){

 $file_tmp =$_FILES['file']['tmp_name']; 

 $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));

$filename=date("Ymdhsi").$user_data['user_id'].".".$file_ext;
move_uploaded_file($file_tmp,"public/uploads/".$filename);

}




		$data=array(
"fromdate"=>date("Y-m-d",strtotime($this->input->post('fromdate'))),
"todate"=>date("Y-m-d",strtotime($this->input->post('todate'))),
"desc"=>$this->input->post('desc'),
"filesata"=>$filename,
"created_at"=>date("Y-m-d"),
"user_id"=>$user_data['user_id'],

		);

 $res=$this->Dashboardmodal->insert_data($data);


$this->session->set_flashdata('msg','Successfully added');
redirect('addReport');

	}else{
		
		redirect("login");
	}



	}
	}

public function reportByUser(){
$user_data = $this->session->userdata('user_data');

if(!empty($user_data)){
 $res['user_data']=$user_data;
 $res['userlist']=$this->Dashboardmodal->userlist($user_data);

$userid=0;
if(isset($_GET['userid'])){
$userid=$_GET['userid'];
}

 $res['report']=$this->Dashboardmodal->reportByUser($userid,$user_data);


			$this->load->view('reportByUser',$res);
	}

}

public function ViewReport(){
$user_data = $this->session->userdata('user_data');

if(!empty($user_data)){
 $res['user_data']=$user_data;

 $res['report']=$this->Dashboardmodal->viewreport($user_data);


			$this->load->view('ViewReport',$res);
	}

}

public function UserReport($userid){
$user_data = $this->session->userdata('user_data');

if(!empty($user_data)){
 $res['user_data']=$user_data;

 $res['report']=$this->Dashboardmodal->UserReport($userid);


			$this->load->view('UserReport',$res);
	}

}




	public function editReport($id){
		$user_data = $this->session->userdata('user_data');
if(!empty($user_data)){
	$res['reportdata']=$this->Dashboardmodal->viewreportByid($id);

			$this->load->view('addreport',$res);
	}
}






}
